<?php

use App\Http\Controllers\WelcomeController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\AuthenticatedSessionController;
use App\Http\Controllers\LogoutController;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\ProfielWachtwoordController;
use App\Http\Controllers\ProfielOppasserController;
use App\Http\Controllers\ProfielJouwDierenController;
use App\Http\Controllers\OppasserController;
use App\Http\Controllers\OppasnodigController;
use App\Http\Controllers\OppasprofielController;
use App\Http\Controllers\OppasnodigprofielController;
use App\Http\Controllers\OppassersAnimalController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
public function __invoke(){
        return view('landpage');
    }
*/

Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/', WelcomeController::class)->name('/');
    Route::get('/login', [AuthenticatedSessionController::class, 'create'])->name('login');
    Route::post('/login', [AuthenticatedSessionController::class, 'store']);
    Route::get('/registreer', [RegisterController::class, 'create'])->name('registreer');
    Route::post('/registreer', [RegisterController::class, 'store']);

    Route::get('/logout', [LogoutController::class, 'logout'])->name('logout');

    Route::get('account', [AccountController::class, 'create'])->name('account');
    Route::post('account', [AccountController::class, 'update'])->name('account.update');

    Route::get('wachtwoord', [ProfielWachtwoordController::class, 'create'] )->name('wachtwoord');
    Route::post('wachtwoord', [ProfielWachtwoordController::class, 'update'] )->name('wachtwoord.update');

    Route::get('oppasser', [ProfielOppasserController::class, 'create'] )->name('oppasser');
    Route::put('oppasser', [ProfielOppasserController::class, 'update'] )->name('oppasser.update');

    Route::get('jouw_dieren', [ProfielJouwDierenController::class, 'create'])->name('jouw_dieren');
    Route::put('jouw_dieren', [ProfielJouwDierenController::class, 'update'])->name('jouw_dieren.update');

    Route::get('oppasnodig', [OppasnodigController::class, 'index'])->name('oppasnodig');
    Route::post('oppasnodig', [OppasnodigController::class, 'remove'])->name('oppasnodig.remove');
    Route::get('oppasnodigprofiel', [OppasnodigprofielController::class, 'index'])->name('oppasnodigprofiel');

    Route::get('oppassers', [OppasserController::class, 'index'])->name('oppassers');
    Route::post('oppassers', [OppasserController::class, 'remove'])->name('oppassers.remove');
    Route::get('oppasprofiel', [OppasprofielController::class, 'index'])->name('oppasprofiel');
    Route::post('oppasprofiel', [OppasprofielController::class, 'update'])->name('oppasprofiel.update');

    Route::get('/tablenav', [OppassersAnimalController::class, 'search'])->name('oppassers.animals.search');
});

Route::middleware(['guest'])->group(function () {
    Route::get('/', WelcomeController::class)->name('/');
    Route::get('/login', [AuthenticatedSessionController::class, 'create'])->name('login');
    Route::post('/login', [AuthenticatedSessionController::class, 'store']);
    Route::get('/registreer', [RegisterController::class, 'create'])->name('registreer');
    Route::post('/registreer', [RegisterController::class, 'store']);
});

Route::get('/', WelcomeController::class)->name('/');
Route::get('/login', [AuthenticatedSessionController::class, 'create'])->name('login');
Route::post('/login', [AuthenticatedSessionController::class, 'store']);
Route::get('/registreer', [RegisterController::class, 'create'])->name('registreer');
Route::post('/registreer', [RegisterController::class, 'store']);

