<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOppassersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('oppassers', function (Blueprint $table) {
            $table->foreignId('user_id')->nullable()->constrained('users')->onUpdate('cascade')->onDelete('cascade');
            $table->id();
            $table->unsignedInteger('kosten')->default(0);
            $table->boolean('katten')->default(0);
            $table->boolean('honden')->default(0);
            $table->boolean('knaagdieren')->default(0);
            $table->boolean('vogels')->default(0);
            $table->boolean('reptielen')->default(0);
            $table->boolean('planten')->default(0);
            $table->boolean('anders')->default(0);
            $table->boolean('beschikbaar')->default(0);
            $table->unsignedTinyInteger('score')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('oppassers');
    }
}
