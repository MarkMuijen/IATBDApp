<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateJouwDierenProfielenTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('jouw_dieren_profielen', function (Blueprint $table) {
            $table->foreignId('user_id')->nullable()->constrained('users')->onUpdate('cascade')->onDelete('cascade');
            $table->id();
            $table->unsignedTinyInteger('hoeveelDieren')->default(0);
            $table->string('hoelangNodig')->default("");
            $table->unsignedInteger('betaald')->default(0);
            $table->string('omschrijving')->default('');
            $table->boolean('katten')->default(0);
            $table->boolean('honden')->default(0);
            $table->boolean('knaagdieren')->default(0);
            $table->boolean('vogels')->default(0);
            $table->boolean('reptielen')->default(0);
            $table->boolean('planten')->default(0);
            $table->boolean('anders')->default(0);
            $table->boolean('nodig')->default(0);
            $table->binary('dierenImage')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('jouw_dieren_profielen');
    }
}
