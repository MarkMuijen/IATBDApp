<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class JouwDierenProfielFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'hoeveelDieren' => $this->faker->numberBetween($min = 1, $max = 10),
            'hoelangNodig' => $this->faker->words($nb = 3, $asText = true),
            'betaald' => $this->faker->numberBetween($min = 50, $max = 500),
            'omschrijving' => $this->faker->text($maxNbChar = 200),
            'katten' => $this->faker->boolean(),
            'honden' => $this->faker->boolean(),
            'knaagdieren' => $this->faker->boolean(),
            'vogels' => $this->faker->boolean(),
            'reptielen' => $this->faker->boolean(),
            'planten' => $this->faker->boolean(),
            'anders' => $this->faker->boolean(),
            'dierenImage' => $this->faker->imageUrl($width = 150, $height = 150),
            'nodig' => $this->faker->boolean(),
        ];
    }
}
