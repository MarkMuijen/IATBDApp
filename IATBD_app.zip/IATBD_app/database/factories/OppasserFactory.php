<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class OppasserFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'kosten' => $this->faker->numberBetween($min = 10, $max = 30),
            'katten' => $this->faker->boolean(),
            'honden' => $this->faker->boolean(),
            'knaagdieren' => $this->faker->boolean(),
            'vogels' => $this->faker->boolean(),
            'reptielen' => $this->faker->boolean(),
            'planten' => $this->faker->boolean(),
            'anders' => $this->faker->boolean(),
            'beschikbaar' => $this->faker->boolean(),
            'score' => $this->faker->numberBetween($min = 1, $max = 10),
        ];
    }
}
