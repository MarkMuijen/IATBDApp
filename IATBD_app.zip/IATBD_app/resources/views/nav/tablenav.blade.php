@if ($oppassers = true)

@endif
<form action="{{route('oppassers.animals.search')}}" method="GET">
    <select class="tableSelect" name="dieren_id" id="search-select" onchange="this.form.submit()">
        <option value="" selected>Alle dieren</option>
        <option value="katten">Katten</option>
        <option value="honden">Honden</option>
        <option value="knaagdieren">Knaagdieren</option>
        <option value="vogels">Vogels</option>
        <option value="reptielen">Reptielen</option>
        <option value="planten">Planten</option>
        <option value="anders">Anders</option>
    </select>
    <input class="tableSearch" type="text" name="query" id="search-input" placeholder="Zoeken...">
    <button type="submit" class="searchicon"><i class="fa fa-search" aria-hidden="true"></i></button>
</form>
