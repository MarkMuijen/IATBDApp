<nav class="profielNav">
    <ul>
        <li>
            <a href="{{route('account') }}">Jouw info</a>
        </li>
        <li>
            <a href="{{route('wachtwoord') }}">Wachtwoord</a>
        </li>
        <li>
            <a href="{{route('oppasser') }}">Oppasser</a>
        </li>
        <li>
            <a href="{{route('jouw_dieren') }}">Jouw Dieren</a>
        </li>
    </ul>
</nav>
