<nav>
    <a class="titel" href="{{route('/') }}">Passen op je Dier</a>
    <a class="login" href="{{route('login') }}">Login</a>
    <a class="registreer" href="{{route('registreer') }}">Registreer</a>
</nav>
@yield('content')
