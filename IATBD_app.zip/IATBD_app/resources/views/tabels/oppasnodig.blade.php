@extends('head.publichead')
<body>
    @extends('nav.authnav')

    @section('content')
    <main>
        <header class="tableHeader">
            <form class="tableForm">
                @include('nav.tablenav')
                <h2 class="tableTitle">Alle Beschikbare Oppassers</h2>
            </form>
        </header>
        <table>
            <thead>
                <tr>
                    <th scope="col">Naam</th>
                    <th scope="col" class="thHd">Hoeveel dieren</th>
                    <th scope="col" class="thD">Diersoorten</th>
                    <th scope="col">Hoelang nodig</th>
                    <th scope="col">Betaald €</th>
                    <th scope="col" class="thi">Bekijk profiel</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($oppasnodig as $oppasnodig)
                @if ($oppasnodig->nodig == 1)
                <tr>
                    <td scope="row">{{$oppasnodig->name}}</td>
                    <td>{{$oppasnodig->hoeveelDieren}}</td>
                    <td> @if ($oppasnodig->katten == 1)katten @endif
                        @if ($oppasnodig->honden == 1)honden @endif
                        @if ($oppasnodig->knaagdieren == 1)knaagdieren @endif
                        @if ($oppasnodig->vogels == 1)vogels @endif
                        @if ($oppasnodig->reptielen == 1)reptielen @endif
                        @if ($oppasnodig->planten == 1)planten @endif
                        @if ($oppasnodig->anders == 1)anders @endif
                    </td>
                    <td>{{$oppasnodig->hoelangNodig}}</td>
                    <td>{{$oppasnodig->betaald}}</td>
                    <td><a class="tableA" href="{{route('oppasnodigprofiel', ['id' => $oppasnodig->id]) }}" title="show"><i class="fa-solid fa-eye"></i></a>
                    @if ($user->role == 'admin')
                    <form method ="POST" action="{{route('oppasnodig.remove', ['id' => $oppasnodig->id])}}" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="beschikbaar" value="0">
                        <button type="submit" name="remove"><i class="fa fa-trash" aria-hidden="true"></i></button>
                    </form>
                    </td>
                    @endif
                </tr>
                @endif
                @endforeach
            </tbody>
        </table>
    </main>

</body>
</html>
@endsection
