@extends('head.publichead')
<body>
    @extends('nav.authnav')

    @section('content')
    <main>
        <header class="tableHeader">
            <form class="tableForm">
                @include('nav.tablenav')
                <h2 class="tableTitle">Alle Beschikbare Oppassers</h2>
                @if(session('message'))
                    <div class="alert alert-success">
                        {{ session('message') }}
                    </div>
                @endif
            </form>
        </header>
        <table class="tablemain">
            <thead>
                <tr>
                    <th scope="col">Naam</th>
                    <th scope="col" class="thPo">Past op</th>
                    <th scope="col">Kosten €/h</th>
                    <th scope="col">Score</th>
                    <th scope="col" class="thi">Bekijk profiel</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($oppassers as $oppasser)
                @if ($oppasser->beschikbaar == 1)
                <tr>
                    <td scope="row">{{$oppasser->name}}</td>
                    <td> @if ($oppasser->katten == 1)katten @endif
                        @if ($oppasser->honden == 1)honden @endif
                        @if ($oppasser->knaagdieren == 1)knaagdieren @endif
                        @if ($oppasser->vogels == 1)vogels @endif
                        @if ($oppasser->reptielen == 1)reptielen @endif
                        @if ($oppasser->planten == 1)planten @endif
                        @if ($oppasser->anders == 1)anders @endif
                    </td>
                    <td>{{$oppasser->kosten}}</td>
                    <td>{{$oppasser->score}}</td>
                    <td><a class="tableA" href="{{route('oppasprofiel', ['id' => $oppasser->id]) }}" title="show"><i class="fa-solid fa-eye"></i></a>
                    @if ($user->role == 'admin')
                    <form method ="POST" action="{{route('oppassers.remove', ['id' => $oppasser->id])}}" enctype="multipart/form-data">
                        @csrf
                        @method('DELETE')
                        <input type="hidden" name="beschikbaar" value="0">
                        <button type="submit" name="remove"><i class="fa fa-trash fa-2x" aria-hidden="true"></i></button>
                    </form>
                    @endif
                    </td>
                </tr>
                @endif
                @endforeach
            </tbody>
        </table>
    </main>
</body>
</html>
@endsection

