@extends('head.publichead')
<body>
    @extends('nav.authnav')

    @section('content')
    <main class="oppasprofielMain">
        <h2>Oppassers Profiel</h2>
        <article class="oppasprofielArt">
            <article class="profRight">
                <label>Profielfoto</label><br>
                <img src="{{ asset('uploads/image/' . $oppasser->image)}}" alt="..."><br>
                <label>past op</label>
                <p>@if ($oppasser->katten == 1)katten @endif <br>
                    @if ($oppasser->honden == 1)honden @endif <br>
                    @if ($oppasser->knaagdieren == 1)knaagdieren @endif <br>
                    @if ($oppasser->vogels == 1)vogels @endif <br>
                    @if ($oppasser->reptielen == 1)reptielen @endif <br>
                    @if ($oppasser->planten == 1)planten @endif <br>
                    @if ($oppasser->anders == 1)anders @endif</p>
            </article>
            <?php
            ?>
            <label for="Naam">Naam</label>
            <p>{{$oppasser->name}}</p>
            <label>Email</label>
            <p>{{$oppasser->email}}</p>
            <label>telefoon</label>
            <p>{{$oppasser->phone_number}}</p>
            <label>Kosten €/h</label>
            <p>{{$oppasser->kosten}}</p>
            <label>score</label>
            <p>{{$oppasser->score}}</p>
            <form method="POST" action="" enctype="multipart/form-data">
                @csrf
                <label>geef een cijfer</label>
                <input class="becijfer" type="number" name="score" value="{{$oppasser->score}}">
                <button type="submit" class="update">becijfer</button>
            </form>
            <a href="{{route('oppassers') }}" class="update">Terug</a>
        </article>
    </main>
</body>
</html>
@endsection
