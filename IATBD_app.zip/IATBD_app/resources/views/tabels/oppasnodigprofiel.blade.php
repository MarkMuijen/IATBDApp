@extends('head.publichead')
<body>
    @extends('nav.authnav')

    @section('content')
    <main class="oppasprofielMain">
        <h2>Oppasser nodig Profiel</h2>
        <article class="oppasprofielArt">
            <article class="opprofRight">
                <article class="soortopasprofRight">
                    <label>Diersoorten</label>
                    <p>@if ($oppasnodig->katten == 1)katten @endif
                        @if ($oppasnodig->honden == 1)honden @endif
                        @if ($oppasnodig->knaagdieren == 1)knaagdieren @endif
                        @if ($oppasnodig->vogels == 1)vogels @endif
                        @if ($oppasnodig->reptielen == 1)reptielen @endif
                        @if ($oppasnodig->planten == 1)planten @endif
                        @if ($oppasnodig->anders == 1)anders @endif</p>
                </article>
                <label>Profielfoto</label><br>
                <img src="{{ asset('uploads/image/' . $oppasnodig->image)}}" alt="..."><br>
                <label>Dierenfoto</label><br>
                <img src="{{ asset('uploads/dierenImage/' . $oppasnodig->dierenImage)}}" alt="..."><br>
            </article>
            <label for="Naam">Naam</label>
            <p>{{$oppasnodig->name}}</p>
            <label>Email</label>
            <p>{{$oppasnodig->email}}</p>
            <label>telefoon</label>
            <p>{{$oppasnodig->phone_number}}</p>
            <label>Hoeveel dieren</label>
            <p>{{$oppasnodig->hoeveelDieren}}</p>
            <label>Hoelang nodig</label>
            <p>{{$oppasnodig->hoelangNodig}}</p>
            <label>Betaald €</label>
            <p>{{$oppasnodig->betaald}}</p>
            <a href="{{route('oppasnodig') }}" class="update">Terug</a>
        </article>
    </main>

</body>
</html>
@endsection
