@extends('head.publichead')
<body>
    @extends('nav.publicnav')

    @section('content')
    <header>
        <h1>Passen op je Dier</h1>
        <p>Passen op je Dier maakt het makkelijk<br>
            een oppasser te krijgen voor jouw dier<br>
            En als oppas kan je hier makkelijk<br>
            wat extra verdienen </p>
        <a class="header_login" href="{{route('login') }}">Login</a>
        <a class="header_registreer" href="{{route('registreer') }}">Registreer</a>
    </header>
    <footer>
        <h2 class="links">Altijd een oppasser</h2>
        <h2 class="rechts">Altijd iemand op te passen</h2>
        <p class="links">Kies zelf een oppas die jij vertrouwt op<br>
            basis van reviews en jouw benodigdheden</p>
        <p class="rechts">Bepaal zelf waar je gaat oppassen<br>
            en waar je het liefst op past</p>
    </footer>
</body>
</html>
@endsection
