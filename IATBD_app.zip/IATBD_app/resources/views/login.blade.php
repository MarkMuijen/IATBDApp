@extends('head.publichead')
<body>
    @extends('nav.publicnav')

    @section('content')
    <article class="loginArt">
        <h2>Login</h2>
        <form class="loginForm" action="{{route('login')}}" method="POST">
            @csrf
            <label for="email" class="label">Email</label><br>
            <input type="email" class="input" name="email" value="{{old('email')}}"/><br>
            @error('email')
                <span>
                    <strong>{{ $message }}</strong><br>
                </span>
            @enderror

            <label for="password" class="label">Wachtwoord</label><br>
            <input type="password" class="input" name="password"/><br>
            @error('password')
                <span>
                    <strong>{{ $message }}</strong><br>
                </span>
            @enderror

            <input type="checkbox" class="checkbox" name="remember" value="true" id="customCheck1"/>
            <label for="customCheck1">Herinner mij</label>

            <a href="{{route('/') }}" class="herKnop">Wachtwoord vergeten?</a> <br>

            <button type="submit" class="login_login">Login</button>

            <p>Geen account? <a href="{{route('registreer') }}" class="formKnop">Registreer</a> </p>

        </form>
    </article>
</body>
</html>
@endsection
