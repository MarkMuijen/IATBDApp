@extends('head.publichead')
<body>
    @extends('nav.authnav')

    @section('content')
    <article class="profielart">
        <h2>Jouw Profiel</h2>
        <article class="inProfArt">
            <form class="infoForm" method="POST" action="{{route('jouw_dieren.update')}}" enctype="multipart/form-data">
                @csrf
                @method('put')
                <article class="formRight">
                    <label>Diersoorten</label><br>
                    <input type="checkbox" class="checkbox" name="katten" value="{{$jouwDieren->katten}}" @if ($jouwDieren->katten == 1) checked @endif id="katten"/><label for="katten">Katten</label><br>
                    <input type="checkbox" class="checkbox" name="honden" value="{{$jouwDieren->honden}}" @if ($jouwDieren->honden == 1) checked @endif id="honden"/><label for="honden">Honden</label><br>
                    <input type="checkbox" class="checkbox" name="knaagdieren" value="{{$jouwDieren->knaagdieren}}" @if ($jouwDieren->knaagdieren == 1) checked @endif id="knaagdieren"/><label for="knaagdieren">Knaagdieren</label><br>
                    <input type="checkbox" class="checkbox" name="vogels" value="{{$jouwDieren->vogels}}" @if ($jouwDieren->vogels == 1) checked @endif id="vogels"/><label for="vogels">Vogels</label><br>
                    <input type="checkbox" class="checkbox" name="reptielen" value="{{$jouwDieren->reptielen}}" @if ($jouwDieren->reptielen == 1) checked @endif id="reptielen"/><label for="reptielen">Reptielen</label><br>
                    <input type="checkbox" class="checkbox" name="planten" value="{{$jouwDieren->planten}}" @if ($jouwDieren->planten == 1) checked @endif id="planten"/><label for="planten">Planten</label><br>
                    <input type="checkbox" class="checkbox" name="anders" value="1" @if ($jouwDieren->anders == 1) checked @endif id="anders"/><label for="anders">Anders</label><br><br>
                    <label class="label">Dierenfoto</label><br>
                    @if ($jouwDieren->dierenImage == NULL)
                        <img src="{{ asset('https://via.placeholder.com/150x150') }}" alt="..."><br>
                        @else
                        <img src="{{ asset('uploads/dierenImage/' . $jouwDieren->dierenImage) }}" alt="..."><br>
                    @endif
                    <input class="upload" type="file" name="dierenImage" accept="image/*,.pdf"><br>
                </article>
                <label for="nodig">Nodigheid</label><br>
                <input type="checkbox" class="checkbox" name="nodig" value="1" @if ($jouwDieren->nodig == 1) checked @endif id="nodig"/><label for="nodig">Nodig</label><br>
                <p class="formp">Wanneer deze op nodig staat verschijnt je profiel in de lijst met hebben oppassers nodig</p><br>
                <label class="label">Hoeveel Dieren</label><br>
                <input class="profinput" type="number" name="hoeveelDieren" value="{{$jouwDieren->hoeveelDieren}}"><br>
                <label class="label">Hoelang nodig</label><br>
                <input class="profinput" type="text" name="hoelangNodig" value="{{$jouwDieren->hoelangNodig}}"><br>
                <label class="label">Betaald</label><br>
                <input class="profinput" type="number" name="betaald" value="{{$jouwDieren->betaald}}"><br>
                <label class="label">omschrijving</label><br>
                <input class="profinput" type="text" name="omschrijving" value="{{$jouwDieren->omschrijving}}"><br>

                <button type="submit" class="update">Update Dierenprofiel</button>
            </form>
        </article>
        @include('nav.profielnav')
    </article>
</body>
</html>
@endsection
