@extends('head.publichead')
<body>
    @extends('nav.authnav')

    @section('content')
    <article class="profielart">
        <h2>Jouw Profiel</h2>
        <article class="inProfArt">
            <form class="infoForm" method="POST" action="{{ route('wachtwoord.update') }}">
                @csrf
                <label class="label">Huidig Wachtwoord</label><br>
                <input class="profinput" type="password" name="current_password"><br>
                <label class="label">Nieuw Wachtwoord</label><br>
                <input class="profinput" type="password" name="new_password"><br>
                <label class="label">Nieuw Wachtwoord Confirmatie</label><br>
                <input class="profinput" type="password" name="new_password_confirmation"><br>
                <button type="submit" class="update">Update Wachtwoord</button>
            </form>
        </article>
        @include('nav.profielnav')
    </article>
</body>
</html>
@endsection
