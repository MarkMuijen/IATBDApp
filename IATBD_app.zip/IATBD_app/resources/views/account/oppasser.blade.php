@extends('head.publichead')
<body>
    @extends('nav.authnav')

    @section('content')
    <article class="profielart">
        <h2>Jouw Profiel</h2>
        <article class="inProfArt">
            <form class="infoForm" method="POST" action="{{route('oppasser.update')}}">
                @csrf
                @method('put')
                <label class="label">Kosten €/h</label><br>
                <input class="profinput" type="number" name="kosten" value="{{$oppasser->kosten}}"><br>

                <label>Diersoorten</label><br>
                <input type="checkbox" class="checkbox" name="katten" value="{{$oppasser->katten}}" @if ($oppasser->katten == 1) checked @endif id="katten"/><label for="katten">Katten</label><br>
                <input type="checkbox" class="checkbox" name="honden" value="{{$oppasser->honden}}" @if ($oppasser->honden == 1) checked @endif id="honden"/><label for="honden">Honden</label><br>
                <input type="checkbox" class="checkbox" name="knaagdieren" value="{{$oppasser->knaagdieren}}" @if ($oppasser->knaagdieren == 1) checked @endif id="knaagdieren"/><label for="knaagdieren">Knaagdieren</label><br>
                <input type="checkbox" class="checkbox" name="vogels" value="{{$oppasser->vogels}}" @if ($oppasser->vogels == 1) checked @endif id="vogels"/><label for="vogels">Vogels</label><br>
                <input type="checkbox" class="checkbox" name="reptielen" value="{{$oppasser->reptielen}}" @if ($oppasser->reptielen == 1) checked @endif id="reptielen"/><label for="reptielen">Reptielen</label><br>
                <input type="checkbox" class="checkbox" name="planten" value="{{$oppasser->planten}}" @if ($oppasser->planten == 1) checked @endif id="planten"/><label for="planten">Planten</label><br>
                <input type="checkbox" class="checkbox" name="anders" value="1" @if ($oppasser->anders == 1) checked @endif id="anders"/><label for="anders">Anders</label><br><br>
                <label for="Beschikbaarheid">Beschikbaarheid</label><br>
                <input type="checkbox" class="checkbox" name="beschikbaar" value="1" @if ($oppasser->beschikbaar == 1) checked @endif id="beschikbaar"/><label for="beschikbaar">Beschikbaar</label><br>
                <p>Wanneer deze op beschikbaar staat verschijnt je profiel in de lijst met oppassers</p><br>

                <p>Score: {{$oppasser->score}} </p>

                <button type="submit" class="update">Update Oppassersprofiel</button>
        </article>
        @include('nav.profielnav')
    </article>
</body>
</html>
@endsection
