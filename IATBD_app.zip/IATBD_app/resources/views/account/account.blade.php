@extends('head.publichead')
<body>
    @extends('nav.authnav')

    @section('content')
    <article class="profielart">
        <h2>Jouw Profiel</h2>
        <article class="inProfArt">
            <form class="infoForm" method="post" action="{{ route('account.update') }}" enctype="multipart/form-data">
                @csrf
                <label class="label">Naam</label><br>
                <input class="profinput" type="text" name="name" value="{{ $user->name }}"><br>
                <label class="label">Email</label><br>
                <input class="profinput" type="email" name="email" value="{{ $user->email }}"><br>
                <label class="label">Telefoon</label><br>
                <input class="profinput" type="tel" name="phone_number" value="{{ $user->phone_number }}"><br>
                <label class="label">Profielfoto</label><br>
                @if ($user->image == NULL)
                <img src="{{ asset('https://via.placeholder.com/150x150') }}" alt="..."><br>
                @else
                <img src="{{ asset('uploads/image/' . $user->image) }}" alt="..."><br>
                @endif
                <input class="upload" type="file" name="image" accept="image/*,.pdf"><br>
                <button type="submit" class="update">Update profiel</button>
            </form>
        </article>
        @include('nav.profielnav')
    </article>
</body>
</html>
@endsection
