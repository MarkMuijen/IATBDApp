@extends('head.publichead')
<body>
    @extends('nav.publicnav')

    @section('content')
    <article class="loginArt">
        <h2>Registreer</h2>
        <form action="{{route('registreer')}}" method="POST" class="loginForm">
            @csrf
            <label for="name" class="label">Naam</label><br>
            <input type="text" class="input" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus/><br>
            @error('name')
                <span>
                    <strong>{{ $message }}</strong><br>
                </span>
            @enderror

            <label for="email" class="label">Email</label><br>
            <input type="email" class="input" name="email" value="{{old('email')}}"/><br>
            @error('email')
                <span>
                    <strong>{{ $message }}</strong><br>
                </span>
            @enderror

            <label for="password" class="label">Wachtwoord</label><br>
            <input type="password" class="input" name="password"/><br>
            @error('password')
                <span>
                    <strong>{{ $message }}</strong><br>
                </span>
            @enderror

            <label for="password" class="label">Wachtwoord confirmatie</label><br>
            <input type="password" class="input" name="password_confirmation" required autocomplete="new-password"/><br>

            <button type="submit" class="login_login">{{ __('Registreer') }}</button>

            <p>Geen account? <a href="{{route('login') }}" class="formKnop">Login</a> </p>

            <a href="{{route('account') }}" class="formKnop">naar account moet nog weg</a>

        </form>
    </article>
</body>
</html>
@endsection
