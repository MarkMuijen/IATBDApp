<nav>
    <ul>
        <li>
            <a href="<?php echo e(route('/')); ?>">Passen op je Dier</a>
        </li>
        <li>
            <a href="<?php echo e(route('/')); ?>">Login</a>
        </li>
        <li>
            <a href="<?php echo e(route('/')); ?>">Registreer</a>
        </li>
    </ul>
</nav>
<?php /**PATH /root/IATBD_app/resources/views/nav/public.blade.php ENDPATH**/ ?>