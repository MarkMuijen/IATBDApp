<body>
    

    <?php $__env->startSection('content'); ?>
    <main>
        <header class="tableHeader">
            <form class="tableForm">
                <?php echo $__env->make('nav.tablenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <h2 class="tableTitle">Hebben oppasser nodig</h2>
                <?php if(session('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php endif; ?>
            </form>
        </header>
        <table>
            <thead>
                <tr>
                    <th scope="col">Naam</th>
                    <th scope="col" class="thHd">Hoeveel dieren</th>
                    <th scope="col" class="thD">Diersoorten</th>
                    <th scope="col">Hoelang nodig</th>
                    <th scope="col">Betaald €</th>
                    <th scope="col" class="thi">Bekijk profiel</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $oppasnodig; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oppasnodig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($oppasnodig->nodig == 1): ?>
                <tr>
                    <td scope="row"><?php echo e($oppasnodig->name); ?></td>
                    <td><?php echo e($oppasnodig->hoeveelDieren); ?></td>
                    <td> <?php if($oppasnodig->katten == 1): ?>katten <?php endif; ?>
                        <?php if($oppasnodig->honden == 1): ?>honden <?php endif; ?>
                        <?php if($oppasnodig->knaagdieren == 1): ?>knaagdieren <?php endif; ?>
                        <?php if($oppasnodig->vogels == 1): ?>vogels <?php endif; ?>
                        <?php if($oppasnodig->reptielen == 1): ?>reptielen <?php endif; ?>
                        <?php if($oppasnodig->planten == 1): ?>planten <?php endif; ?>
                        <?php if($oppasnodig->anders == 1): ?>anders <?php endif; ?>
                    </td>
                    <td><?php echo e($oppasnodig->hoelangNodig); ?></td>
                    <td><?php echo e($oppasnodig->betaald); ?></td>
                    <td><a class="tableA" href="<?php echo e(route('oppasnodigprofiel', ['id' => $oppasnodig->id])); ?>" title="show"><i class="fa-solid fa-eye"></i></a>
                    <?php if($user->role == 'admin'): ?>

                    <form method ="POST" action="<?php echo e(route('oppasnodig.remove', ['id' => $oppasnodig->id])); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="hidden" name="beschikbaar" value="0">
                        <button type="submit" name="remove"><a><i class="fa fa-trash fa-2x" aria-hidden="true"></i></a></button>
                    </form>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </main>

</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nav.authnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('head.publichead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/IATBD_app/resources/views/tabels/oppasnodig.blade.php ENDPATH**/ ?>