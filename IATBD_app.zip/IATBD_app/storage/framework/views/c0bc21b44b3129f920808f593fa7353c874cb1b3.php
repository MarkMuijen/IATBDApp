<body>
    

    <?php $__env->startSection('content'); ?>
    <article class="profielart">
        <h2>Jouw Profiel</h2>
        <article class="inProfArt">
            <form class="infoForm" method="post" action="<?php echo e(route('account.update')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <label class="label">Naam</label><br>
                <input class="profinput" type="text" name="name" value="<?php echo e($user->name); ?>"><br>
                <label class="label">Email</label><br>
                <input class="profinput" type="email" name="email" value="<?php echo e($user->email); ?>"><br>
                <label class="label">Telefoon</label><br>
                <input class="profinput" type="tel" name="phone_number" value="<?php echo e($user->phone_number); ?>"><br>
                <label class="label">Profielfoto</label><br>
                <?php if($user->image == NULL): ?>
                <img src="<?php echo e(asset('https://via.placeholder.com/150x150')); ?>" alt="..."><br>
                <?php else: ?>
                <img src="<?php echo e(asset('uploads/image/' . $user->image)); ?>" alt="..."><br>
                <?php endif; ?>
                <input class="upload" type="file" name="image" accept="image/*,.pdf"><br>
                <button type="submit" class="update">Update profiel</button>
            </form>
        </article>
        <?php echo $__env->make('nav.profielnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </article>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nav.authnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('head.publichead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/IATBD_app/resources/views/account/account.blade.php ENDPATH**/ ?>