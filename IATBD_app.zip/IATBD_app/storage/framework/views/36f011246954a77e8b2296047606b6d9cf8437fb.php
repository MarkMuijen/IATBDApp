<body>
    

    <?php $__env->startSection('content'); ?>
    <main>
        <header class="tableHeader">
            <form class="tableForm">
                <?php echo $__env->make('nav.tablenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <h2 class="tableTitle">Alle Beschikbare Oppassers</h2>
            </form>
        </header>
        <table>
            <thead>
                <tr>
                    <th scope="col">Naam</th>
                    <th scope="col" class="thPo">Past op</th>
                    <th scope="col">Kosten €/h</th>
                    <th scope="col">Score</th>
                    <th scope="col" class="thi">Bekijk profiel</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $oppassers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oppasser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($oppasser->beschikbaar == 1): ?>
                <tr>
                    <td scope="row"><?php echo e($oppasser->name); ?></td>
                    <td> <?php if($oppasser->katten == 1): ?>katten <?php endif; ?>
                        <?php if($oppasser->honden == 1): ?>honden <?php endif; ?>
                        <?php if($oppasser->knaagdieren == 1): ?>knaagdieren <?php endif; ?>
                        <?php if($oppasser->vogels == 1): ?>vogels <?php endif; ?>
                        <?php if($oppasser->reptielen == 1): ?>reptielen <?php endif; ?>
                        <?php if($oppasser->planten == 1): ?>planten <?php endif; ?>
                        <?php if($oppasser->anders == 1): ?>anders <?php endif; ?>
                    </td>
                    <td><?php echo e($oppasser->kosten); ?></td>
                    <td><?php echo e($oppasser->score); ?></td>
                    <td><a class="tableA" href="<?php echo e(route('oppasprofiel', ['id' => $oppasser->id])); ?>" title="show"><i class="fa-solid fa-eye"></i></a>
                    <?php if($user->role == 'admin'): ?>
                    <form method ="POST" action="<?php echo e(route('oppassers.remove', ['id' => $oppasser->id])); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="beschikbaar" value="0">
                        <button type="submit" name="remove"><i class="fa fa-trash" aria-hidden="true"></i></button>
                    </form>
                    <?php endif; ?>
                    </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </main>
</body>
</html>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('nav.authnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('head.publichead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/IATBD_app/resources/views/tabels/oppassers.blade.php ENDPATH**/ ?>