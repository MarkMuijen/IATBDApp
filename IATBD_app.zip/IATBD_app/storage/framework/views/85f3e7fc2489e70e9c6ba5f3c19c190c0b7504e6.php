<body>
    

    <?php $__env->startSection('content'); ?>
    <article class="loginArt">
        <h2>Registreer</h2>
        <form action="<?php echo e(route('registreer')); ?>" method="POST" class="loginForm">
            <?php echo csrf_field(); ?>
            <label for="name" class="label">Naam</label><br>
            <input type="text" class="input" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus/><br>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span>
                    <strong><?php echo e($message); ?></strong><br>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label for="email" class="label">Email</label><br>
            <input type="email" class="input" name="email" value="<?php echo e(old('email')); ?>"/><br>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span>
                    <strong><?php echo e($message); ?></strong><br>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label for="password" class="label">Wachtwoord</label><br>
            <input type="password" class="input" name="password"/><br>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span>
                    <strong><?php echo e($message); ?></strong><br>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label for="password" class="label">Wachtwoord confirmatie</label><br>
            <input type="password" class="input" name="password_confirmation" required autocomplete="new-password"/><br>

            <button type="submit" class="login_login"><?php echo e(__('Registreer')); ?></button>

            <p>Geen account? <a href="<?php echo e(route('login')); ?>" class="formKnop">Login</a> </p>

        </form>
    </article>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nav.publicnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('head.publichead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/IATBD_app/resources/views/registreer.blade.php ENDPATH**/ ?>