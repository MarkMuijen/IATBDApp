<article class="profielart">
    <h2>Jouw Profiel</h2>
    <article class="infoArt">

    </article>
    <nav class="profielNav">
        <ul>
            <li>
                <a href="<?php echo e(route('account')); ?>">Jouw info</a>
            </li>
            <li>
                <a href="<?php echo e(route('/')); ?>">Wachtwoord</a>
            </li>
            <li>
                <a href="<?php echo e(route('/')); ?>">Oppasser</a>
            </li>
            <li>
                <a href="<?php echo e(route('/')); ?>">Jouw Dieren</a>
            </li>
        </ul>
    </nav>

</article>
<?php /**PATH /root/IATBD_app/resources/views/profiel/profiel.blade.php ENDPATH**/ ?>