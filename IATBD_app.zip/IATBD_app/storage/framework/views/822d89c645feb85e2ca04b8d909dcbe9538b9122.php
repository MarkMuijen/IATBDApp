<nav>
    <a class="titel" href="<?php echo e(route('/')); ?>">Passen op je Dier</a>
    <a class="login" href="<?php echo e(route('login')); ?>">Login</a>
    <a class="registreer" href="<?php echo e(route('registreer')); ?>">Registreer</a>
</nav>
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH /root/IATBD_app/resources/views/nav/publicnav.blade.php ENDPATH**/ ?>