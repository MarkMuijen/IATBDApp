<nav>
    <a class="titel" href="<?php echo e(route('/')); ?>">Passen op je Dier</a>
    <a class="navtxt1" href="<?php echo e(route('oppassers')); ?>">Beschikbare Oppassers</a>
    <a class="navtxt2" href="<?php echo e(route('oppasnodig')); ?>">Hebben Oppassers Nodig</a>
    <nav class="dropmenu">
        <p>GebruikersNaam</p>
        <ul class="dropitems">
            <li>
                <a href="<?php echo e(route('account')); ?>">Profiel</a>
            </li>
            <li>
                <a href="<?php echo e(route('logout')); ?>">Logout</a>
            </li>
        </ul>
    </nav>
</nav>
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH /root/IATBD_app/resources/views/nav/authnav.blade.php ENDPATH**/ ?>