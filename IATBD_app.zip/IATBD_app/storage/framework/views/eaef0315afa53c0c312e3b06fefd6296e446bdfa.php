<nav class="profielNav">
    <ul>
        <li>
            <a href="<?php echo e(route('account')); ?>">Jouw info</a>
        </li>
        <li>
            <a href="<?php echo e(route('wachtwoord')); ?>">Wachtwoord</a>
        </li>
        <li>
            <a href="<?php echo e(route('oppasser')); ?>">Oppasser</a>
        </li>
        <li>
            <a href="<?php echo e(route('jouw_dieren')); ?>">Jouw Dieren</a>
        </li>
    </ul>
</nav>
<?php /**PATH /root/IATBD_app/resources/views/nav/profielnav.blade.php ENDPATH**/ ?>