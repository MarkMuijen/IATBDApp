<body>
    

    <?php $__env->startSection('content'); ?>
    <main class="oppasprofielMain">
        <h2>Oppasser nodig Profiel</h2>
        <article class="oppasprofielArt">
            <article class="opprofRight">
                <article class="soortopasprofRight">
                    <label>Diersoorten</label>
                    <p><?php if($oppasnodig->katten == 1): ?>katten <?php endif; ?>
                        <?php if($oppasnodig->honden == 1): ?>honden <?php endif; ?>
                        <?php if($oppasnodig->knaagdieren == 1): ?>knaagdieren <?php endif; ?>
                        <?php if($oppasnodig->vogels == 1): ?>vogels <?php endif; ?>
                        <?php if($oppasnodig->reptielen == 1): ?>reptielen <?php endif; ?>
                        <?php if($oppasnodig->planten == 1): ?>planten <?php endif; ?>
                        <?php if($oppasnodig->anders == 1): ?>anders <?php endif; ?></p>
                </article>
                <label>Profielfoto</label><br>
                <img src="<?php echo e(asset('uploads/image/' . $oppasnodig->image)); ?>" alt="..."><br>
                <label>Dierenfoto</label><br>
                <img src="<?php echo e(asset('uploads/dierenImage/' . $oppasnodig->dierenImage)); ?>" alt="..."><br>
            </article>
            <label for="Naam">Naam</label>
            <p><?php echo e($oppasnodig->name); ?></p>
            <label>Email</label>
            <p><?php echo e($oppasnodig->email); ?></p>
            <label>telefoon</label>
            <p><?php echo e($oppasnodig->phone_number); ?></p>
            <label>Hoeveel dieren</label>
            <p><?php echo e($oppasnodig->hoeveelDieren); ?></p>
            <label>Hoelang nodig</label>
            <p><?php echo e($oppasnodig->hoelangNodig); ?></p>
            <label>Betaald €</label>
            <p><?php echo e($oppasnodig->betaald); ?></p>
            <a href="<?php echo e(route('oppasnodig')); ?>" class="update">Terug</a>
        </article>
    </main>

</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nav.authnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('head.publichead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/IATBD_app/resources/views/tabels/oppasnodigprofiel.blade.php ENDPATH**/ ?>