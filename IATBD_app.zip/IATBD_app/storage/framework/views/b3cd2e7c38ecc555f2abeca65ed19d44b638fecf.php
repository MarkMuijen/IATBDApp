<article class="infoArt">

</article>
<?php /**PATH /root/IATBD_app/resources/views/profiel/info.blade.php ENDPATH**/ ?>