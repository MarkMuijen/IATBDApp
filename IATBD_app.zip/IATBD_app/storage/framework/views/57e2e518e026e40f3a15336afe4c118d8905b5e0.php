<body>
    

    <?php $__env->startSection('content'); ?>
    <article class="profielart">
        <h2>Jouw Profiel</h2>
        <article class="inProfArt">
            <form class="infoForm" method="POST" action="<?php echo e(route('wachtwoord.update')); ?>">
                <?php echo csrf_field(); ?>
                <label class="label">Huidig Wachtwoord</label><br>
                <input class="profinput" type="password" name="current_password"><br>
                <label class="label">Nieuw Wachtwoord</label><br>
                <input class="profinput" type="password" name="new_password"><br>
                <label class="label">Nieuw Wachtwoord Confirmatie</label><br>
                <input class="profinput" type="password" name="new_password_confirmation"><br>
                <button type="submit" class="update">Update Wachtwoord</button>
            </form>
        </article>
        <?php echo $__env->make('nav.profielnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </article>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nav.authnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('head.publichead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/IATBD_app/resources/views/account/wachtwoord.blade.php ENDPATH**/ ?>