<body>
    

    <?php $__env->startSection('content'); ?>
    <article class="loginArt">
        <h2>Login</h2>
        <form class="loginForm" action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <label for="email" class="label">Email</label><br>
            <input type="email" class="input" name="email" value="<?php echo e(old('email')); ?>"/><br>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span>
                    <strong><?php echo e($message); ?></strong><br>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label for="password" class="label">Wachtwoord</label><br>
            <input type="password" class="input" name="password"/><br>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span>
                    <strong><?php echo e($message); ?></strong><br>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <input type="checkbox" class="checkbox" name="remember" value="true" id="customCheck1"/>
            <label for="customCheck1">Herinner mij</label>

            <a href="<?php echo e(route('/')); ?>" class="herKnop">Wachtwoord vergeten?</a> <br>

            <button type="submit" class="login_login">Login</button>

            <p>Geen account? <a href="<?php echo e(route('registreer')); ?>" class="formKnop">Registreer</a> </p>

        </form>
    </article>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nav.publicnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('head.publichead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/IATBD_app/resources/views/login.blade.php ENDPATH**/ ?>