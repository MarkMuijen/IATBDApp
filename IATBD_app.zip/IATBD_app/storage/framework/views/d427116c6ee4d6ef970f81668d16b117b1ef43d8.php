<body>
    

    <?php $__env->startSection('content'); ?>
    <main class="oppasprofielMain">
        <h2>Oppassers Profiel</h2>
        <article class="oppasprofielArt">
            <article class="profRight">
                <label>Profielfoto</label><br>
                <img src="<?php echo e(asset('uploads/image/' . $oppasser->image)); ?>" alt="..."><br>
                <label>past op</label>
                <p><?php if($oppasser->katten == 1): ?>katten <?php endif; ?> <br>
                    <?php if($oppasser->honden == 1): ?>honden <?php endif; ?> <br>
                    <?php if($oppasser->knaagdieren == 1): ?>knaagdieren <?php endif; ?> <br>
                    <?php if($oppasser->vogels == 1): ?>vogels <?php endif; ?> <br>
                    <?php if($oppasser->reptielen == 1): ?>reptielen <?php endif; ?> <br>
                    <?php if($oppasser->planten == 1): ?>planten <?php endif; ?> <br>
                    <?php if($oppasser->anders == 1): ?>anders <?php endif; ?></p>
            </article>
            <?php
            ?>
            <label for="Naam">Naam</label>
            <p><?php echo e($oppasser->name); ?></p>
            <label>Email</label>
            <p><?php echo e($oppasser->email); ?></p>
            <label>telefoon</label>
            <p><?php echo e($oppasser->phone_number); ?></p>
            <label>Kosten €/h</label>
            <p><?php echo e($oppasser->kosten); ?></p>
            <label>score</label>
            <p><?php echo e($oppasser->score); ?></p>
            <form method="POST" action="" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <label>geef een cijfer</label>
                <input class="becijfer" type="number" name="score" value="<?php echo e($oppasser->score); ?>">
                <button type="submit" class="update">becijfer</button>
            </form>
            <a href="<?php echo e(route('oppassers')); ?>" class="update">Terug</a>
        </article>
    </main>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nav.authnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('head.publichead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/IATBD_app/resources/views/tabels/oppasprofiel.blade.php ENDPATH**/ ?>