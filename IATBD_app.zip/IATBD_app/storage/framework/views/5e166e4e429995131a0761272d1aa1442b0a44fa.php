<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(asset('main.css')); ?>" rel="stylesheet">
    <script src="https://kit.fontawesome.com/da9a7f8cce.js" crossorigin="anonymous"></script>
    <title>Passen op je Dier</title>
</head>



<?php /**PATH /root/IATBD_app/resources/views/head/publichead.blade.php ENDPATH**/ ?>