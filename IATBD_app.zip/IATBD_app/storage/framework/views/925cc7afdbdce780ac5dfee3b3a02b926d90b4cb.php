<body>
    

    <?php $__env->startSection('content'); ?>
    <article class="profielart">
        <h2>Jouw Profiel</h2>
        <article class="inProfArt">
            <form class="infoForm" method="POST" action="<?php echo e(route('oppasser.update')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <label class="label">Kosten €/h</label><br>
                <input class="profinput" type="number" name="kosten" value="<?php echo e($oppasser->kosten); ?>"><br>

                <label>Diersoorten</label><br>
                <input type="checkbox" class="checkbox" name="katten" value="<?php echo e($oppasser->katten); ?>" <?php if($oppasser->katten == 1): ?> checked <?php endif; ?> id="katten"/><label for="katten">Katten</label><br>
                <input type="checkbox" class="checkbox" name="honden" value="<?php echo e($oppasser->honden); ?>" <?php if($oppasser->honden == 1): ?> checked <?php endif; ?> id="honden"/><label for="honden">Honden</label><br>
                <input type="checkbox" class="checkbox" name="knaagdieren" value="<?php echo e($oppasser->knaagdieren); ?>" <?php if($oppasser->knaagdieren == 1): ?> checked <?php endif; ?> id="knaagdieren"/><label for="knaagdieren">Knaagdieren</label><br>
                <input type="checkbox" class="checkbox" name="vogels" value="<?php echo e($oppasser->vogels); ?>" <?php if($oppasser->vogels == 1): ?> checked <?php endif; ?> id="vogels"/><label for="vogels">Vogels</label><br>
                <input type="checkbox" class="checkbox" name="reptielen" value="<?php echo e($oppasser->reptielen); ?>" <?php if($oppasser->reptielen == 1): ?> checked <?php endif; ?> id="reptielen"/><label for="reptielen">Reptielen</label><br>
                <input type="checkbox" class="checkbox" name="planten" value="<?php echo e($oppasser->planten); ?>" <?php if($oppasser->planten == 1): ?> checked <?php endif; ?> id="planten"/><label for="planten">Planten</label><br>
                <input type="checkbox" class="checkbox" name="anders" value="1" <?php if($oppasser->anders == 1): ?> checked <?php endif; ?> id="anders"/><label for="anders">Anders</label><br><br>
                <label for="Beschikbaarheid">Beschikbaarheid</label><br>
                <input type="checkbox" class="checkbox" name="beschikbaar" value="1" <?php if($oppasser->beschikbaar == 1): ?> checked <?php endif; ?> id="beschikbaar"/><label for="beschikbaar">Beschikbaar</label><br>
                <p>Wanneer deze op beschikbaar staat verschijnt je profiel in de lijst met oppassers</p><br>

                <p>Score: <?php echo e($oppasser->score); ?> </p>

                <button type="submit" class="update">Update Oppassersprofiel</button>
        </article>
        <?php echo $__env->make('nav.profielnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </article>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nav.authnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('head.publichead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/IATBD_app/resources/views/account/oppasser.blade.php ENDPATH**/ ?>