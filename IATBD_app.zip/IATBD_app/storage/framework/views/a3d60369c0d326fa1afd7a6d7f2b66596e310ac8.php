<body>
    

    <?php $__env->startSection('content'); ?>
    <article class="profielart">
        <h2>Jouw Profiel</h2>
        <article class="inProfArt">
            <form class="infoForm" method="POST" action="<?php echo e(route('jouw_dieren.update')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <article class="formRight">
                    <label>Diersoorten</label><br>
                    <input type="checkbox" class="checkbox" name="katten" value="<?php echo e($jouwDieren->katten); ?>" <?php if($jouwDieren->katten == 1): ?> checked <?php endif; ?> id="katten"/><label for="katten">Katten</label><br>
                    <input type="checkbox" class="checkbox" name="honden" value="<?php echo e($jouwDieren->honden); ?>" <?php if($jouwDieren->honden == 1): ?> checked <?php endif; ?> id="honden"/><label for="honden">Honden</label><br>
                    <input type="checkbox" class="checkbox" name="knaagdieren" value="<?php echo e($jouwDieren->knaagdieren); ?>" <?php if($jouwDieren->knaagdieren == 1): ?> checked <?php endif; ?> id="knaagdieren"/><label for="knaagdieren">Knaagdieren</label><br>
                    <input type="checkbox" class="checkbox" name="vogels" value="<?php echo e($jouwDieren->vogels); ?>" <?php if($jouwDieren->vogels == 1): ?> checked <?php endif; ?> id="vogels"/><label for="vogels">Vogels</label><br>
                    <input type="checkbox" class="checkbox" name="reptielen" value="<?php echo e($jouwDieren->reptielen); ?>" <?php if($jouwDieren->reptielen == 1): ?> checked <?php endif; ?> id="reptielen"/><label for="reptielen">Reptielen</label><br>
                    <input type="checkbox" class="checkbox" name="planten" value="<?php echo e($jouwDieren->planten); ?>" <?php if($jouwDieren->planten == 1): ?> checked <?php endif; ?> id="planten"/><label for="planten">Planten</label><br>
                    <input type="checkbox" class="checkbox" name="anders" value="1" <?php if($jouwDieren->anders == 1): ?> checked <?php endif; ?> id="anders"/><label for="anders">Anders</label><br><br>
                    <label class="label">Dierenfoto</label><br>
                    <?php if($jouwDieren->dierenImage == NULL): ?>
                        <img src="<?php echo e(asset('https://via.placeholder.com/150x150')); ?>" alt="..."><br>
                        <?php else: ?>
                        <img src="<?php echo e(asset('uploads/dierenImage/' . $jouwDieren->dierenImage)); ?>" alt="..."><br>
                    <?php endif; ?>
                    <input class="upload" type="file" name="dierenImage" accept="image/*,.pdf"><br>
                </article>
                <label for="nodig">Nodigheid</label><br>
                <input type="checkbox" class="checkbox" name="nodig" value="1" <?php if($jouwDieren->nodig == 1): ?> checked <?php endif; ?> id="nodig"/><label for="nodig">Nodig</label><br>
                <p class="formp">Wanneer deze op nodig staat verschijnt je profiel in de lijst met hebben oppassers nodig</p><br>
                <label class="label">Hoeveel Dieren</label><br>
                <input class="profinput" type="number" name="hoeveelDieren" value="<?php echo e($jouwDieren->hoeveelDieren); ?>"><br>
                <label class="label">Hoelang nodig</label><br>
                <input class="profinput" type="text" name="hoelangNodig" value="<?php echo e($jouwDieren->hoelangNodig); ?>"><br>
                <label class="label">Betaald</label><br>
                <input class="profinput" type="number" name="betaald" value="<?php echo e($jouwDieren->betaald); ?>"><br>
                <label class="label">omschrijving</label><br>
                <input class="profinput" type="text" name="omschrijving" value="<?php echo e($jouwDieren->omschrijving); ?>"><br>

                <button type="submit" class="update">Update Dierenprofiel</button>
            </form>
        </article>
        <?php echo $__env->make('nav.profielnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </article>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nav.authnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('head.publichead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /root/IATBD_app/resources/views/account/jouw_dieren.blade.php ENDPATH**/ ?>