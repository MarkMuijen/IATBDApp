<?php

namespace App\Http\Controllers;

use App\Http\Requests\ContactRequest;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Models\Oppasser;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;

class OppasnodigprofielController extends Controller
{
    protected function Users($id)
    {
        return DB::table('users')
            ->join('jouw_dieren_profielen', 'user_id', '=', 'users.id')
            ->where('users.id', $id)
            ->first();
    }

    public function index(Request $request)
    {
        $id = $request->id;
        $oppasnodig = $this->Users($id);

        return view('tabels/oppasnodigprofiel' , compact('oppasnodig', 'id'));
    }
}
