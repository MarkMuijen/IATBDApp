<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Models\Oppasser;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;

class OppasnodigController extends Controller
{
    protected function Users()
    {
        return (DB::table('users')->join('jouw_dieren_profielen', 'users.id', '=', 'jouw_dieren_profielen.user_id')->get());
    }

    public function index()
    {
        $oppasnodig = $this->Users();
        $user = auth()->user();
        return view('tabels/oppasnodig', compact('oppasnodig', 'user'));
    }

    public function remove(Request $request)
    {
        $user = $request->id;

        $oppasser = Oppasser::whereHas('user', function($query) use ($user) {
            $query->where('id', $user);
        })->first();

        $oppasser->beschikbaar = 0;

        $oppasser->save();

        return redirect()->route('oppassers');
    }
}
