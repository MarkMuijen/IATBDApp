<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class OppassersAnimalController extends Controller
{
        public function search(Request $request)
    {
        $query = $request->input('query');
        $animalType = $request->input('dieren_id');

        dd($animalType);

        return view('oppassers.index', [
            'animals' => $results,
            'selectedType' => $animalType,
            'query' => $query,
        ]);
    }
}
