<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AccountController extends Controller
{
        public function create()
        {
            $user = auth()->user();
            return view('account/account', compact('user'));
        }

        public function update(Request $request)
        {
            $user = auth()->user();

            $validatedData = $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|string|email|max:255|unique:users,email,'.$user->id,
                'phone_number' => 'nullable|string',
                'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            ]);

            $user->name = $validatedData['name'];
            $user->email = $validatedData['email'];
            $user->phone_number = $validatedData['phone_number'];

            if ($request->hasFile('image')) {
                $image = $request->file('image');
                $imageName = time().'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/uploads/image');
                $image->move($destinationPath, $imageName);
                $user->image = $imageName;
            }

            $user->save();

            return redirect()->route('account')->with('success', 'Profiel succesvol bijgewerkt!');
        }
}
