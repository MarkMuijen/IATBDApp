<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\JouwDierenProfiel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProfielJouwDierenController extends Controller
{
    public function create()
    {
        $user = Auth::user();
        $jouwDieren = $user->jouwDierenProfiel()->firstOrCreate([]);
        return view('account/jouw_dieren', compact('user', 'jouwDieren'));
    }

    public function update(Request $request)
    {
        $validatedData = $request->validate([
            'katten' => 'nullable|boolean',
            'honden' => 'nullable|boolean',
            'knaagdieren' => 'nullable|boolean',
            'vogels' => 'nullable|boolean',
            'reptielen' => 'nullable|boolean',
            'planten' => 'nullable|boolean',
            'anders' => 'nullable|boolean',
            'nodig' => 'nullable|boolean',
            'hoeveelDieren' => 'numeric|required',
            'hoelangNodig' => 'required|string|max:255',
            'betaald' => 'numeric|required',
            'omschrijving' => 'nullable|string|max:255',
            'dierenImage' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        $user = Auth::user();
        $jouwDieren = jouwDierenProfiel::whereHas('user', function($query) use ($user) {
            $query->where('id', $user->id);
        })->first();

        $jouwDieren->katten = isset($validatedData['katten']) ? 1 : 0;
        $jouwDieren->honden = isset($validatedData['honden']) ? 1 : 0;
        $jouwDieren->knaagdieren = isset($validatedData['knaagdieren']) ? 1 : 0;
        $jouwDieren->vogels = isset($validatedData['vogels']) ? 1 : 0;
        $jouwDieren->reptielen = isset($validatedData['reptielen']) ? 1 : 0;
        $jouwDieren->planten = isset($validatedData['planten']) ? 1 : 0;
        $jouwDieren->anders = isset($validatedData['anders']) ? 1 : 0;
        $jouwDieren->nodig = isset($validatedData['nodig']) ? 1 : 0;
        $jouwDieren->hoeveelDieren = $validatedData['hoeveelDieren'];
        $jouwDieren->hoelangNodig = $validatedData['hoelangNodig'];
        $jouwDieren->betaald = $validatedData['betaald'];
        $jouwDieren->omschrijving = $validatedData['omschrijving'];

        if ($request->hasFile('dierenImage')) {
            $file = $request->file('dierenImage');
            $filename = time() . '_' . $file->getClientOriginalName();
            $destinationPath = public_path('/uploads/dierenImage');
            $file->move($destinationPath, $filename);
            $jouwDieren->dierenImage = $filename;
        }

        $jouwDieren->save();

        return redirect()->route('jouw_dieren')->with('success', 'Dierenprofiel succesvol bijgewerkt!');
    }
}
