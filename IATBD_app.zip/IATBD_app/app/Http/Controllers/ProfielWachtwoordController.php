<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Validation\Rules;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class ProfielWachtwoordController extends Controller
{
    public function create()
    {
        return view('account/wachtwoord');
    }

    public function update(Request $request)
    {
        $request->validate([
            'current_password' => ['required', Rules\Password::defaults()],
            'new_password' => ['required', 'min:8', 'different:current_password'],
            'new_password_confirmation' => ['required', 'same:new_password'],
        ]);

        $user = Auth::user();
        $user->update(['password' => Hash::make($request->new_password)]);

        return redirect()->route('wachtwoord')->with('success', 'Wachtwoord succesvol gewijzigd!');
    }
}
