<?php

namespace App\Http\Controllers;

use App\Http\Requests\ContactRequest;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Models\Oppasser;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Auth;

class OppasprofielController extends Controller
{
        protected function Users($id)
    {
        return DB::table('users')
            ->join('oppassers', 'user_id', '=', 'users.id')
            ->where('users.id', $id)
            ->first();
    }

    public function index(Request $request)
    {
        $id = $request->id;
        $oppasser = $this->Users($id);

        return view('tabels/oppasprofiel' , compact('oppasser', 'id'));
    }

    public function update(Request $request){

        $user = $request->id;

        $oppasser = Oppasser::whereHas('user', function($query) use ($user) {
            $query->where('id', $user);
        })->first();

        $validatedData = $request->validate([
            'score' => 'required|numeric|min:0|max:10'
        ]);

        $oppasser->score = $validatedData['score'];

        $oppasser->save();

        return redirect()->route('account');
    }

}
