<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Models\Oppasser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProfielOppasserController extends Controller
{
    public function create()
    {
        /*$user_id = Auth::user()->id;
        $user = User::find($user_id);

        $oppasser = Oppasser::join('users', 'users.id', '=', 'oppassers.user_id')
                    ->where('users.id', $user_id)
                    ->first();

                    return view('account/oppasser', compact('user', 'oppasser'));*/

        $user = Auth::user();
        $oppasser = $user->oppasser()->firstOrCreate([]);
        return view('account/oppasser', compact('user', 'oppasser'));
    }

    public function update(Request $request)
    {

        $validatedData = $request->validate([
            'kosten' => 'required|numeric|min:0',
            'katten' => 'nullable|boolean',
            'honden' => 'nullable|boolean',
            'knaagdieren' => 'nullable|boolean',
            'vogels' => 'nullable|boolean',
            'reptielen' => 'nullable|boolean',
            'planten' => 'nullable|boolean',
            'anders' => 'nullable|boolean',
            'beschikbaar' => 'nullable|boolean',
        ]);

        $user = Auth::user();

        $oppasser = Oppasser::whereHas('user', function($query) use ($user) {
            $query->where('id', $user->id);
        })->first();

        $oppasser->kosten = $validatedData['kosten'];
        $oppasser->katten = isset($validatedData['katten']) ? 1 : 0;
        $oppasser->honden = isset($validatedData['honden']) ? 1 : 0;
        $oppasser->knaagdieren = isset($validatedData['knaagdieren']) ? 1 : 0;
        $oppasser->vogels = isset($validatedData['vogels']) ? 1 : 0;
        $oppasser->reptielen = isset($validatedData['reptielen']) ? 1 : 0;
        $oppasser->planten = isset($validatedData['planten']) ? 1 : 0;
        $oppasser->anders = isset($validatedData['anders']) ? 1 : 0;
        $oppasser->beschikbaar = isset($validatedData['beschikbaar']) ? 1 : 0;

        $oppasser->save();

        return redirect()->route('oppasser')->with('success', 'Oppasser profiel succesvol bijgewerkt!');
    }
}
