<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JouwDierenProfiel extends Model
{
    use HasFactory;

    protected $table = "jouw_dieren_profielen";

    protected $fillable = [
        'user_id',
        'HoeveelDieren',
        'hoelangNodig',
        'betaald',
        'omschrijving',
        'katten',
        'honden',
        'knaagdieren',
        'vogels',
        'reptielen',
        'planten',
        'anders',
        'nodig',
        'dierenImage',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
